﻿namespace WildFarm.Foods
{
	class Seeds : Food
	{
		public Seeds(int quantity) : base(quantity)
		{
		}
	}
}
