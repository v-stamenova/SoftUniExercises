﻿namespace WildFarm.Foods
{
	class Vegetable : Food
	{
		public Vegetable(int quantity) : base(quantity)
		{
		}
	}
}
